package com.example.user.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.example.user.R;
import com.example.user.myapp.country.Country;


/**
 * An activity representing a list of Countries. This activity
 * has different presentations for handset and tablet-size devices. On
 * handsets, the activity presents a list of items, which when touched,
 * lead to a {@link CountryDetailActivity} representing
 * item details. On tablets, the activity presents the list of items and
 * item details side-by-side using two vertical panes.
 * <p/>
 * This activity also implements the required
 * interface
 * to listen for item selections.
 */
public class CountryListActivity extends ActionBarActivity
        implements CountryListFragment.Callbacks {

    /**
     * Whether or not the activity is in two-pane mode, i.e. running on a tablet
     * device.
     */
    private boolean mTwoPane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_list);

        if (findViewById(R.id.country_detail_container) != null) {
            mTwoPane = true;

            ((CountryListFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.country_list))
                    .setActivateOnItemClick(true);
        }

        // TODO: If exposing deep links into your app, handle intents here.


    }

    @Override
    public void onItemSelected(Country country) {
        if (mTwoPane) {
            Bundle arguments = new Bundle();

            arguments.putString(CountryDetailFragment.ARG_COUNTRY_CODE, country.code);
            arguments.putString(CountryDetailFragment.ARG_COUNTRY_NAME, country.name);
            CountryDetailFragment fragment = new CountryDetailFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.country_detail_container, fragment)
                    .commit();

        } else {
            Intent detailIntent = new Intent(this, CountryDetailActivity.class);
            detailIntent.putExtra(CountryDetailFragment.ARG_COUNTRY_NAME, country.name);
            detailIntent.putExtra(CountryDetailFragment.ARG_COUNTRY_CODE, country.code);
            startActivity(detailIntent);
        }
    }

    @Override
    public void onSaveInstanceState ( Bundle outState ) {
        super.onSaveInstanceState(outState);

        outState.putInt("test", 1);

    }

    @Override
    public void onDestroy( ) {
        super.onDestroy();
    }



}
