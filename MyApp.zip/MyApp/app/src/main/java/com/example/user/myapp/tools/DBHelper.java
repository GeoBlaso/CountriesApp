package com.example.user.myapp.tools;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper extends SQLiteOpenHelper {


    static public final String DB_NAME = "countriesDatabase.db";
    static public final int DB_VERSION = 1;
public String table_name = "countriesData";
    static public final String id_column = "_id";
    static public final String code_column = "code";
    static public final String name_column = "name";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        String creation_string = "CREATE TABLE "+ table_name + " ("+ id_column +
                " INTEGER PRIMARY KEY," + name_column + " TEXT," + code_column + " TEXT)";

        db.execSQL(creation_string);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + table_name);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }
}
