package com.example.user.myapp;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.R;
import com.example.user.myapp.tools.FlagCache;
import com.example.user.myapp.weather.WeatherMain;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class CountryDetailFragment extends Fragment {

    public static final String ARG_COUNTRY_CODE = "country_code";
    public static final String ARG_COUNTRY_NAME = "country_name";
    ImageView bmImage;
    int REQUEST_CAMERA = 0;
    Button btnSelect;
    private String countryName = null ;
    private String countryCode = null ;
    private FlagCache flagCache;
    WebView myBrowser;


    public CountryDetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments().containsKey(ARG_COUNTRY_CODE)) {
            countryCode = getArguments().getString(ARG_COUNTRY_CODE);
        }

        if (getArguments().containsKey(ARG_COUNTRY_NAME)) {
            countryName = getArguments().getString(ARG_COUNTRY_NAME);
        }
        flagCache = new FlagCache(this.getActivity());

    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_country_detail, container, false);

        if (countryName != null) {
            ((TextView) rootView.findViewById(R.id.name)).setText(countryName);
        }

        if (countryCode != null ) {
            Drawable flag = flagCache.recoverFlagFromCache(countryCode);
            if(flag == null) {

                String lowerCaseCode = countryCode.toLowerCase();
                String Url="http://www.apptones.net/test02_assets/"+lowerCaseCode+".png";

                new FlagDownloadTask((ImageView) rootView.findViewById(R.id.flag))
                        .execute(Url);

            }else{

                bmImage = null;

                BitmapDrawable drawable = (BitmapDrawable) ((ImageView) rootView.findViewById(R.id.flag)).getDrawable();
                Bitmap bitmap = drawable.getBitmap();
                bmImage.setImageBitmap(bitmap);
                bmImage.setAlpha(0f);
                bmImage.animate().alpha(1f)
                        .setDuration(2)
                        .setListener(null);

            }

                  }
        btnSelect = (Button) rootView.findViewById(R.id.btnSelectPhoto);
        btnSelect.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_CAMERA);
            }
        });
        myBrowser = (WebView) rootView.findViewById(R.id.mybrowser);
          myBrowser.setWebViewClient(new MyBrowser());
         myBrowser.getSettings().setJavaScriptEnabled(true);
        myBrowser.loadUrl("file:///android_asset/mypage.html");
        return rootView;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if ( resultCode == Activity.RESULT_OK)
        {
        super.onActivityResult(requestCode, resultCode, data);
        onCaptureImageResult(data);}

    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        bmImage.setImageBitmap(thumbnail);
        bmImage.setAlpha(0f);
        bmImage.animate().alpha(1f)
                .setDuration(2)
                .setListener(null);
    }
    private class MyBrowser extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url.equals("file:///activity_b://SecondActivity")) {
                Intent i = new Intent(getActivity(), Map.class);
            i.putExtra("country_n",countryName);

                startActivity(i);
                getActivity().finish();
                //  startActivity(i);
                return true;
            }
            else if (url.equals("file:///activity_c://weather.WeatherMain")) {
                Intent i = new Intent(getActivity(), WeatherMain.class);
                i.putExtra("country_n",countryName);

                startActivity(i);
                getActivity().finish();
                return true;
            }
            return false;
        }
    }
    private class FlagDownloadTask extends AsyncTask<String, String, Bitmap> {



        public FlagDownloadTask(ImageView bmImages) {
            bmImage = bmImages;
        }
        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
            bmImage.setAlpha(0f);
            bmImage.animate().alpha(1f)
                    .setDuration(2)
                    .setListener(null);

        }


    }}
