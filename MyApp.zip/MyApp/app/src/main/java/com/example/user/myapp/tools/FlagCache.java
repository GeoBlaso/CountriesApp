package com.example.user.myapp.tools;

import android.content.Context;
import android.graphics.drawable.Drawable;

import java.io.File;
public class FlagCache {

    public File directory;
    public FlagCache(Context context){

        try {
            directory = context.getCacheDir();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public Drawable recoverFlagFromCache(String countryCode){

        try{
        return Drawable.createFromPath(directory.getPath() + "/" + countryCode + ".png");

        } catch(Exception e){
            e.printStackTrace();
            return null;
        }

    }

    }

