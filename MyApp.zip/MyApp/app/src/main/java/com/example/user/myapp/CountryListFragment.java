package com.example.user.myapp;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.example.user.myapp.adapters.CountryCursorAdapter;
import com.example.user.myapp.tools.DBHelper;
import com.example.user.R;
import com.example.user.myapp.country.Country;
import com.example.user.myapp.tools.ServiceHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CountryListFragment extends ListFragment {
 private static final String STATE_ACTIVATED_POSITION = "activated_position";
    private static final String CURRENT_SCROLL_INDEX = "current_scroll_index" ;
    private static final String CURRENT_SCROLL_TOP = "current_scroll_top";
    private Callbacks mCallbacks = sDummyCallbacks;
    private int mActivatedPosition = ListView.INVALID_POSITION;

    private CountryCursorAdapter countryCursorAdapter;

    private JSONDownloadTask myDLTask;
    private static final String url = "http://www.apptones.net/test02_assets/countries.json";

    private DBHelper countryDBHelper;
    private SQLiteDatabase countryDB;
    private Cursor countryCursor;

    public interface Callbacks {

        public void onItemSelected(Country country);
    }
    private static Callbacks sDummyCallbacks = new Callbacks() {
        @Override
        public void onItemSelected(Country country) {
        }
    };
    public CountryListFragment() {

    }
    @Override
    public void onListItemClick(ListView listView, View view, int position, long id) {
        super.onListItemClick(listView, view, position, id);
Cursor clickedCursor = (Cursor) listView.getItemAtPosition(position);
        String name= clickedCursor.getString(clickedCursor.getColumnIndexOrThrow("name"));
        String code= clickedCursor.getString(clickedCursor.getColumnIndexOrThrow("code" ));
        mCallbacks.onItemSelected(new Country(name,code));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
   countryDBHelper = new DBHelper(getActivity());
        countryDB = countryDBHelper.getWritableDatabase();
        countryCursor = countryDB.rawQuery("SELECT * FROM " + countryDBHelper.table_name +
                " ORDER BY " + countryDBHelper.name_column + " ASC", null);

        countryCursorAdapter = new CountryCursorAdapter(getActivity(),countryCursor,0);
        setListAdapter(countryCursorAdapter);

        myDLTask = new JSONDownloadTask();
        myDLTask.execute(url);

        setHasOptionsMenu(true);
    }


    @Override
    public void onStart(){
        super.onStart();
        if(myDLTask.getStatus() == AsyncTask.Status.RUNNING){
        }else{
            myDLTask = new JSONDownloadTask();
            myDLTask.execute(url);
        }
    }
    @Override
    public void onResume(){
        super.onResume();
        if(myDLTask.getStatus() == AsyncTask.Status.RUNNING){
        }else{
            myDLTask = new JSONDownloadTask();
            myDLTask.execute(url);
        }
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (savedInstanceState != null
                && savedInstanceState.containsKey(STATE_ACTIVATED_POSITION)) {
            setActivatedPosition(savedInstanceState.getInt(STATE_ACTIVATED_POSITION));
        }
    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        if (!(activity instanceof Callbacks)) {
            throw new IllegalStateException("Activity must implement fragment's callbacks.");
        }

        mCallbacks = (Callbacks) activity;
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = sDummyCallbacks;
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mActivatedPosition != ListView.INVALID_POSITION) {

            outState.putInt(STATE_ACTIVATED_POSITION, mActivatedPosition);
        }
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }
    public void setActivateOnItemClick(boolean activateOnItemClick) {
        // When setting CHOICE_MODE_SINGLE, ListView will automatically
        // give items the 'activated' state when touched.
        getListView().setChoiceMode(activateOnItemClick
                ? ListView.CHOICE_MODE_SINGLE
                : ListView.CHOICE_MODE_NONE);
    }
    private void setActivatedPosition(int position) {
        if (position == ListView.INVALID_POSITION) {
            getListView().setItemChecked(mActivatedPosition, false);
        } else {
            getListView().setItemChecked(position, true);
        }

        mActivatedPosition = position;
    }

    private class JSONDownloadTask extends AsyncTask<String, String, JSONArray> {

        @Override
        public JSONArray doInBackground(String... sUrl) {


            ServiceHandler sh = new ServiceHandler();
            String jsonStr = sh.makeServiceCall(url);

            Log.d("Response: ", "> " + jsonStr);
            JSONArray jsonArray = null;
            try {
                jsonArray = new JSONArray(jsonStr);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
            return jsonArray;

        }


        @Override
        protected void onPostExecute(JSONArray jsonArray) {
            super.onPostExecute(jsonArray);

            SQLiteDatabase countryDB = countryDBHelper.getWritableDatabase();
try{
            if (jsonArray != null)
            {
                for(int element = 0; element < jsonArray.length(); element++)
                {
                    JSONObject retrievedObject = jsonArray.getJSONObject(element);
                    String name = retrievedObject.getString("fullname");
                    String code = retrievedObject.getString("ianacode");

                    Cursor selectCountry = countryDB.rawQuery("SELECT * FROM " + countryDBHelper.table_name +
                            " WHERE " + countryDBHelper.name_column + " LIKE '%" + name.substring(0,4) + "%'", null);
                    if (selectCountry.getCount() == 0) {
                        ContentValues initialValues = new ContentValues();

                        initialValues.put(countryDBHelper.name_column, name);
                        initialValues.put(countryDBHelper.code_column, code);

                        countryDB.insert(countryDBHelper.table_name, null, initialValues);
                    }
                }
            Cursor selectCountries = countryDB.rawQuery("SELECT * FROM " + countryDBHelper.table_name
                    + " ORDER BY " + countryDBHelper.name_column + " ASC", null);
            countryCursorAdapter.getCursor().close();
            countryCursorAdapter.changeCursor(selectCountries);

        }
    } catch (JSONException e) {
    e.printStackTrace();
}}}


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main_menu, menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.refresh:
                if(myDLTask.getStatus() == AsyncTask.Status.RUNNING){
                }else{
                    myDLTask = new JSONDownloadTask();
                    myDLTask.execute(url);
                }

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
