package com.example.user.myapp.country;

public class Country {

    public String name   ;
    public String code   ;

    public Country (String name, String code){
        this.name = name;
        this.code = code;
    }

}
