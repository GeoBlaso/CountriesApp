package com.example.user.myapp.adapters;

import android.annotation.TargetApi;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.R;
import com.example.user.myapp.country.Country;

import java.io.InputStream;
public class CountryCursorAdapter extends CursorAdapter {

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public CountryCursorAdapter(Context context, Cursor c, int flags) {
        super(context, c, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_country, parent, false);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        ViewHolder viewHolder = null;

        if(view.getTag() != null){
            ViewHolder holder = (ViewHolder) view.getTag();
            holder.downloadImageTask.cancel(true);
        }
        viewHolder = new ViewHolder();
        viewHolder.name = (TextView) view.findViewById(R.id.name);
        viewHolder.flag = (ImageView) view.findViewById(R.id.flag);
        viewHolder.flag.setImageResource(R.drawable.white_flag);

        view.setTag(viewHolder);
        String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
        String code = cursor.getString(cursor.getColumnIndexOrThrow("code"));
        Country country = new Country(name, code);
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.name.setText(country.name);
        try {

            String lowerCaseCode = country.code.toLowerCase();
            String Url="http://www.apptones.net/test02_assets/"+lowerCaseCode+".png";
            viewHolder.imageURL = Url;

            holder.downloadImageTask= new DownloadImageTask((ImageView) view.findViewById(R.id.flag));

            holder.downloadImageTask.execute(Url);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    private class ViewHolder {
        private TextView name;
        private ImageView flag;
        private DownloadImageTask downloadImageTask;
        public String imageURL;
    }
        private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
            ImageView bmImage;

            public DownloadImageTask(ImageView bmImage) {
                this.bmImage = bmImage;
            }

            protected Bitmap doInBackground(String... urls) {
                String urldisplay = urls[0];
                Bitmap mIcon11 = null;
                try {
                    InputStream in = new java.net.URL(urldisplay).openStream();
                    mIcon11 = BitmapFactory.decodeStream(in);
                } catch (Exception e) {
                    Log.e("Error", e.getMessage());
                    e.printStackTrace();
                }
                return mIcon11;
            }

            protected void onCancelled(Bitmap result) {


            }

            protected void onPostExecute(Bitmap result) {
                bmImage.setImageBitmap(result);
                bmImage.setAlpha(0f);
                bmImage.animate().alpha(1f)
                        .setDuration(2)
                        .setListener(null);

            }

        }
    }
